import "./button.css";
function Button() {
  return (
    <button className="button-21" alt="button">
      Watch free
    </button>
  );
}
export default Button;
