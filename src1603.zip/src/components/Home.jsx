import React, { useState, useEffect } from "react";
import Card from "./card";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function Home({ filteredMovies, loadMoreMovies, isLoading }) {
    return (
      <div className="main-cards">
        {filteredMovies.map((movie, index) => (
          <Link
            key={index}
            to={`/card/${encodeURIComponent(movie.original_title)}`}
          >
            <Card movie={movie} />
          </Link>
        ))}
        <div>
          <div className="btn-space"></div>
          <button 
            className="load-more-btn" 
            onClick={loadMoreMovies}
            disabled={isLoading}
            id="movies"
          >
            {isLoading ? 'Loading...' : 'Load More'}
          </button>
        </div>
      </div>
    );
  }
  
  export default Home;