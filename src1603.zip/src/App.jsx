import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import InsideCard from "./components/insideCard";
import getAllTrendingMovies from "./data/database";
import MyList from "./components/myList";
import Top from "./components/top";
import "./style/App.css";
import NotFoundPage from "./components/NotFound";
import SeriesCard from "./components/SeriesCard";
import Series from "./components/series";  // Ensure this import is correct
import Home from "./components/Home";

function App() {
  const [movies, setMovies] = useState([]);
  const [filteredMovies, setFilteredMovies] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchMovies(3);
  }, []);

  const fetchMovies = async (pagesToFetch = 1) => {
    setIsLoading(true);
    let newMovies = [];
    for (let i = 0; i < pagesToFetch; i++) {
      const movies = await getAllTrendingMovies(currentPage + i);
      newMovies = [...newMovies, ...movies];
    }
    setMovies(prevMovies => [...prevMovies, ...newMovies]);
    setFilteredMovies(prevMovies => [...prevMovies, ...newMovies]);
    setCurrentPage(prevPage => prevPage + pagesToFetch);
    setIsLoading(false);
  };

  const handleSearch = (searchQuery) => {
    if (searchQuery.trim() === "") {
      setFilteredMovies(movies);
    } else {
      const filtered = movies.filter(
        (movie) =>
          movie.original_title &&
          movie.original_title
            .toLowerCase()
            .includes(searchQuery.toLowerCase())
      );
      setFilteredMovies(filtered);
    }
  };

  const loadMoreMovies = () => {
    fetchMovies(5);
  };

  return (
    <Router>
      <div className="Main">
        <Top onSearch={handleSearch} />
        <Routes>
          <Route
            path="/"
            element={
              <Home
                filteredMovies={filteredMovies}
                loadMoreMovies={loadMoreMovies}
                isLoading={isLoading}
              />
            }
          />
          <Route
            path="/card/:insideCard"
            element={<InsideCard filteredMovies={filteredMovies} />}
          />
          <Route
            path="/my-list"
            element={<MyList filteredMovies={filteredMovies} />}
          />
          <Route path="/series" element={<Series />} />
          <Route path="/SeriesCard" element={<SeriesCard />} />
          <Route path="*" element={<NotFoundPage/>} />
        </Routes>
      </div>
    </Router>
  );
}


export default App;